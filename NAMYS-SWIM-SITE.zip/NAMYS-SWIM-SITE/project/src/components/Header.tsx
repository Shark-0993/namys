import React, { useState } from 'react';
import { Menu, X, Waves } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const navLinks = [
    { name: 'Главная', href: '/' },
    { name: 'Календарь', href: '/calendar' },
    { name: 'Результаты', href: '/results' },
    { name: 'О нас', href: '/about' },
  ];

  const isActive = (href: string) => location.pathname === href;

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-gray-200">
      <nav className="max-w-7xl mx-auto px-sm py-sm flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-10 h-10 bg-gradient-to-br from-primary-700 to-secondary-500 rounded-lg flex items-center justify-center">
            <Waves className="w-6 h-6 text-white" />
          </div>
          <span className="font-bold text-xl text-primary-900">NAMYS</span>
        </Link>

        <button
          onClick={() => setIsOpen(!isOpen)}
          className="md:hidden text-gray-600 hover:text-primary-700"
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>

        <div className="hidden md:flex items-center gap-lg">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              className={`font-medium text-sm transition-colors ${
                isActive(link.href)
                  ? 'text-primary-700 border-b-2 border-primary-700'
                  : 'text-gray-600 hover:text-primary-700'
              }`}
            >
              {link.name}
            </Link>
          ))}
        </div>

        <div className="hidden md:flex items-center gap-md">
          <Link
            to="/login"
            className="px-lg py-sm font-medium text-primary-700 hover:text-primary-900 transition-colors"
          >
            Вход
          </Link>
          <Link
            to="/register"
            className="px-lg py-sm bg-primary-700 text-white rounded-lg font-medium hover:bg-primary-800 transition-colors"
          >
            Регистрация
          </Link>
        </div>

        {isOpen && (
          <div className="md:hidden absolute top-20 left-0 right-0 bg-white border-b border-gray-200 py-md">
            <div className="flex flex-col gap-md px-sm">
              {navLinks.map((link) => (
                <Link
                  key={link.href}
                  to={link.href}
                  className="font-medium text-gray-600 hover:text-primary-700"
                  onClick={() => setIsOpen(false)}
                >
                  {link.name}
                </Link>
              ))}
              <hr className="border-gray-200" />
              <Link to="/login" className="font-medium text-primary-700">
                Вход
              </Link>
              <Link
                to="/register"
                className="px-lg py-sm bg-primary-700 text-white rounded-lg font-medium text-center"
              >
                Регистрация
              </Link>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}
