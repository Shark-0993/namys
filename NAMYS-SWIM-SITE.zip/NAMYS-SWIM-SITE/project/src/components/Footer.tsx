import React from 'react';
import { Mail, Phone, MapPin, Facebook, Instagram, Linkedin } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="bg-primary-900 text-white mt-2xl">
      <div className="max-w-7xl mx-auto px-sm py-xl">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-xl mb-xl">
          <div>
            <h3 className="font-bold text-lg mb-md">NAMYS-SWIM</h3>
            <p className="text-gray-300 text-sm leading-relaxed">
              Казахстанский клуб Masters Swimming. Объединяем пловцов в возрасте 18+.
            </p>
          </div>

          <div>
            <h4 className="font-semibold mb-md text-base">Навигация</h4>
            <ul className="space-y-sm text-sm text-gray-300">
              <li>
                <Link to="/" className="hover:text-secondary-400 transition">
                  Главная
                </Link>
              </li>
              <li>
                <Link to="/calendar" className="hover:text-secondary-400 transition">
                  Календарь
                </Link>
              </li>
              <li>
                <Link to="/results" className="hover:text-secondary-400 transition">
                  Результаты
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-secondary-400 transition">
                  О нас
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-md text-base">Категории Masters</h4>
            <ul className="space-y-sm text-sm text-gray-300">
              <li>Мужчины / Женщины</li>
              <li>Возраст 18-24 до 80+</li>
              <li>Бассейн 25м / 50м</li>
              <li>Открытая вода</li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold mb-md text-base">Контакты</h4>
            <ul className="space-y-md text-sm text-gray-300">
              <li className="flex items-start gap-md">
                <MapPin size={16} className="mt-0.5 flex-shrink-0" />
                <span>Алматы, Казахстан</span>
              </li>
              <li className="flex items-center gap-md">
                <Phone size={16} />
                <a href="tel:+77XXX000000" className="hover:text-secondary-400">
                  +7 (XXX) 000-0000
                </a>
              </li>
              <li className="flex items-center gap-md">
                <Mail size={16} />
                <a href="mailto:info@namysswim.kz" className="hover:text-secondary-400">
                  info@namysswim.kz
                </a>
              </li>
            </ul>
          </div>
        </div>

        <hr className="border-primary-700 mb-lg" />

        <div className="flex flex-col md:flex-row items-center justify-between">
          <p className="text-sm text-gray-400">
            © 2025 NAMYS-SWIM. Все права защищены.
          </p>

          <div className="flex items-center gap-lg mt-md md:mt-0">
            <a
              href="#"
              className="text-gray-300 hover:text-secondary-400 transition"
            >
              <Facebook size={20} />
            </a>
            <a
              href="#"
              className="text-gray-300 hover:text-secondary-400 transition"
            >
              <Instagram size={20} />
            </a>
            <a
              href="#"
              className="text-gray-300 hover:text-secondary-400 transition"
            >
              <Linkedin size={20} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
