import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Trophy, Users, Zap, Calendar, TrendingUp } from 'lucide-react';

export default function Home() {
  const upcomingEvents = [
    {
      id: 1,
      title: 'Чемпионат Masters 25м',
      date: '15 марта 2025',
      location: 'Бассейн "Дельфин", Алматы',
      type: 'Бассейн',
      distances: '50m, 100m, 200m, 400m',
    },
    {
      id: 2,
      title: 'Открытая вода Masters',
      date: '22 марта 2025',
      location: 'Озеро Балхаш',
      type: 'Открытая вода',
      distances: '1km, 2km, 5km',
    },
    {
      id: 3,
      title: 'Turbo Masters Sprint',
      date: '5 апреля 2025',
      location: 'Бассейн "Олимпийский", Алматы',
      type: 'Бассейн',
      distances: '50m, 100m',
    },
  ];

  const mastersCategories = [
    { label: '18-24', count: 45 },
    { label: '25-29', count: 58 },
    { label: '30-34', count: 92 },
    { label: '35-39', count: 87 },
    { label: '40-44', count: 103 },
    { label: '45-49', count: 78 },
    { label: '50-54', count: 65 },
    { label: '55-59', count: 54 },
    { label: '60-64', count: 41 },
    { label: '65-69', count: 28 },
    { label: '70-74', count: 19 },
    { label: '75-79', count: 12 },
    { label: '80+', count: 8 },
  ];

  const stats = [
    { icon: Users, label: 'Активные участники', value: '690+' },
    { icon: Trophy, label: 'Соревнований проведено', value: '24' },
    { icon: Zap, label: 'Личные рекорды', value: '1,200+' },
  ];

  return (
    <main className="flex-1">
      <section className="relative h-screen md:h-96 lg:h-screen bg-gradient-to-r from-primary-900 via-primary-800 to-secondary-600 flex items-center overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 right-10 w-72 h-72 bg-secondary-400 rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 left-10 w-96 h-96 bg-accent-500 rounded-full blur-3xl"></div>
        </div>

        <div className="max-w-7xl mx-auto px-sm w-full relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-xl items-center">
            <div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-md leading-tight">
                Плавание без границ возраста
              </h1>

              <p className="text-lg md:text-xl text-gray-100 mb-xl leading-relaxed">
                NAMYS-SWIM — казахстанский клуб Masters Swimming. Объединяем пловцов от 18 до 80+ лет. Организуем соревнования в бассейне и на открытой воде, помогаем достигать личных рекордов в любом возрасте.
              </p>

              <div className="flex flex-col md:flex-row gap-md">
                <Link
                  to="/calendar"
                  className="px-lg py-sm md:py-md bg-accent-500 text-white font-bold rounded-lg hover:bg-accent-600 transition-all duration-300 flex items-center justify-center gap-md text-center"
                >
                  Зарегистрироваться на соревнование
                  <ArrowRight size={20} />
                </Link>

                <Link
                  to="/calendar"
                  className="px-lg py-sm md:py-md border-2 border-white text-white font-bold rounded-lg hover:bg-white hover:text-primary-700 transition-all duration-300 text-center"
                >
                  Календарь событий
                </Link>
              </div>
            </div>

            <div className="hidden md:block relative">
              <div className="aspect-square bg-gradient-to-br from-secondary-300 to-secondary-600 rounded-2xl opacity-20"></div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-xl bg-white">
        <div className="max-w-7xl mx-auto px-sm">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-lg">
            {stats.map((stat) => {
              const Icon = stat.icon;
              return (
                <div
                  key={stat.label}
                  className="p-lg bg-gradient-to-br from-primary-50 to-secondary-50 rounded-xl border border-primary-100 hover:border-secondary-300 transition"
                >
                  <Icon className="w-10 h-10 text-secondary-500 mb-md" />
                  <p className="text-gray-600 text-sm mb-sm">{stat.label}</p>
                  <p className="text-3xl font-bold text-primary-900">{stat.value}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-2xl bg-gray-50">
        <div className="max-w-7xl mx-auto px-sm">
          <div className="mb-xl">
            <h2 className="text-3xl md:text-4xl font-bold text-primary-900 mb-md">
              Ближайшие соревнования
            </h2>
            <p className="text-gray-600 text-lg">
              Выберите событие и присоединитесь к лучшим пловцам Masters Казахстана
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-lg">
            {upcomingEvents.map((event) => (
              <div
                key={event.id}
                className="bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 border border-gray-100 overflow-hidden hover:border-secondary-300"
              >
                <div className="h-32 bg-gradient-to-r from-secondary-400 to-secondary-600 p-lg flex flex-col justify-between">
                  <span className="text-white text-xs font-semibold uppercase tracking-wide bg-accent-500 inline-block w-fit px-md py-xs rounded">
                    {event.type}
                  </span>
                  <h3 className="text-white font-bold text-lg">{event.title}</h3>
                </div>

                <div className="p-lg">
                  <div className="space-y-md mb-lg">
                    <div className="flex items-center gap-md text-gray-700">
                      <Calendar size={16} className="text-secondary-500" />
                      <span className="text-sm font-medium">{event.date}</span>
                    </div>
                    <div className="flex items-start gap-md text-gray-700">
                      <div className="text-secondary-500 mt-0.5">
                        <svg
                          className="w-4 h-4"
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path
                            fillRule="evenodd"
                            d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z"
                            clipRule="evenodd"
                          />
                        </svg>
                      </div>
                      <span className="text-sm">{event.location}</span>
                    </div>
                    <div className="text-xs text-gray-500">
                      <span className="font-medium">Дистанции:</span> {event.distances}
                    </div>
                  </div>

                  <Link
                    to="/calendar"
                    className="w-full px-md py-sm bg-primary-700 text-white font-medium rounded-lg hover:bg-primary-800 transition-colors text-center text-sm"
                  >
                    Подробнее
                  </Link>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-xl">
            <Link
              to="/calendar"
              className="inline-flex items-center gap-md px-lg py-sm font-bold text-primary-700 hover:text-primary-900 transition"
            >
              Смотреть весь календарь
              <ArrowRight size={20} />
            </Link>
          </div>
        </div>
      </section>

      <section className="py-2xl bg-white">
        <div className="max-w-7xl mx-auto px-sm">
          <div className="mb-xl">
            <h2 className="text-3xl md:text-4xl font-bold text-primary-900 mb-md">
              Категории Masters
            </h2>
            <p className="text-gray-600 text-lg">
              Соревнования для пловцов возраста 18+ по возрастным группам (FINA Masters)
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-md">
            {mastersCategories.map((cat) => (
              <div
                key={cat.label}
                className="p-md bg-gradient-to-br from-secondary-50 to-primary-50 rounded-lg border border-secondary-100 hover:border-secondary-300 transition text-center"
              >
                <div className="text-2xl font-bold text-primary-700 mb-xs">
                  {cat.label}
                </div>
                <div className="flex items-center justify-center gap-xs text-accent-500">
                  <TrendingUp size={16} />
                  <span className="text-sm font-semibold">{cat.count}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-2xl bg-gradient-to-r from-primary-50 to-secondary-50">
        <div className="max-w-7xl mx-auto px-sm">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2xl items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-primary-900 mb-md">
                О клубе NAMYS-SWIM
              </h2>

              <p className="text-gray-600 text-lg mb-md leading-relaxed">
                NAMYS-SWIM — это движение пловцов Masters, которые верят, что возраст не является преградой для спорта. Мы создаем условия для развития плавания среди взрослых, организуем региональные и международные соревнования.
              </p>

              <p className="text-gray-600 text-lg mb-lg leading-relaxed">
                Наша миссия: популяризировать Masters Swimming в Казахстане, поддерживать здоровый образ жизни, создавать сообщество единомышленников и помогать каждому достичь своих спортивных целей.
              </p>

              <Link
                to="/about"
                className="inline-flex items-center gap-md px-lg py-sm font-bold text-primary-700 hover:text-primary-900 transition"
              >
                Узнать подробнее
                <ArrowRight size={20} />
              </Link>
            </div>

            <div className="hidden md:block">
              <div className="aspect-video bg-gradient-to-br from-secondary-200 to-secondary-400 rounded-2xl"></div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
