import React from 'react';
import { Users, Heart, Target, Award } from 'lucide-react';

export default function About() {
  const team = [
    {
      name: 'Ерланбек Оспанов',
      role: 'Основатель и руководитель',
      bio: 'Олимпийский пловец, мастер спорта. 15+ лет опыта в плавании.',
    },
    {
      name: 'Айгерим Сейтова',
      role: 'Главный тренер',
      bio: 'Кандидат в мастера спорта, специалист по Masters плаванию.',
    },
    {
      name: 'Болат Жангельдинов',
      role: 'Тренер по спринту',
      bio: 'Рекордсмен Казахстана в категории М 50-54.',
    },
    {
      name: 'Гульнур Карибаева',
      role: 'Координатор соревнований',
      bio: 'Организатор крупнейших Masters турниров в Центральной Азии.',
    },
  ];

  const values = [
    {
      icon: Heart,
      title: 'Здоровье и благополучие',
      description: 'Плавание как образ жизни для всех возрастов и способностей',
    },
    {
      icon: Target,
      title: 'Развитие мастерства',
      description: 'Помощь в достижении личных рекордов и спортивных целей',
    },
    {
      icon: Users,
      title: 'Сообщество',
      description: 'Объединение пловцов в дружную семью единомышленников',
    },
    {
      icon: Award,
      title: 'Профессионализм',
      description: 'Высокий уровень организации соревнований по FINA стандартам',
    },
  ];

  return (
    <main className="flex-1">
      <section className="bg-gradient-to-br from-primary-900 to-secondary-700 text-white py-2xl">
        <div className="max-w-7xl mx-auto px-sm">
          <h1 className="text-4xl md:text-5xl font-bold mb-md">О клубе NAMYS-SWIM</h1>
          <p className="text-xl text-gray-100 max-w-2xl">
            Движение Masters Swimming в Казахстане. Объединяем пловцов от 18 до 80+ лет.
          </p>
        </div>
      </section>

      <section className="py-2xl bg-white">
        <div className="max-w-7xl mx-auto px-sm">
          <h2 className="text-3xl font-bold text-primary-900 mb-lg">История клуба</h2>

          <div className="space-y-lg text-gray-600 text-lg leading-relaxed">
            <p>
              NAMYS-SWIM был основан в 2018 году как инициатива группы пловцов, которые верят,
              что спорт не имеет возрастных ограничений. Название клуба происходит от фразы
              "New Age Masters Young Swimmers" — новое поколение Masters пловцов.
            </p>

            <p>
              За семь лет работы мы вырос в крупнейший Masters клуб Казахстана с более чем
              700 активными участниками из всех регионов страны. Мы организовали более 100
              соревнований в бассейне и на открытой воде, в том числе чемпионаты и кубки
              национального уровня.
            </p>

            <p>
              Наш клуб членствует в Федерации плавания Казахстана и следует стандартам
              FINA (Fédération Internationale de Natation) для Masters соревнований. Мы активно
              участвуем в региональных и международных турнирах, представляя спортсменов
              Казахстана на мировой арене.
            </p>
          </div>
        </div>
      </section>

      <section className="py-2xl bg-gray-50">
        <div className="max-w-7xl mx-auto px-sm">
          <h2 className="text-3xl font-bold text-primary-900 mb-lg">Наша миссия</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-xl">
            <div>
              <p className="text-gray-600 text-lg mb-lg leading-relaxed">
                Миссия NAMYS-SWIM — популяризировать Masters Swimming в Казахстане и Центральной
                Азии. Мы создаем возможности для взрослых пловцов развивать свой потенциал,
                независимо от возраста и уровня подготовки.
              </p>

              <p className="text-gray-600 text-lg mb-lg leading-relaxed">
                Мы верим, что плавание способствует не только физическому здоровью, но и
                психологическому благополучию. Каждый участник нашего клуба находит здесь
                вдохновение, поддержку и возможность роста.
              </p>
            </div>

            <div className="bg-white rounded-xl p-lg border border-secondary-200">
              <h3 className="text-xl font-bold text-primary-900 mb-md">Ценности клуба</h3>
              <ul className="space-y-md">
                <li className="flex items-start gap-md">
                  <span className="text-secondary-500 font-bold text-lg">•</span>
                  <span className="text-gray-700">
                    <strong>Инклюзивность:</strong> Плавание для всех возрастов и уровней
                  </span>
                </li>
                <li className="flex items-start gap-md">
                  <span className="text-secondary-500 font-bold text-lg">•</span>
                  <span className="text-gray-700">
                    <strong>Профессионализм:</strong> Высокие стандарты организации
                  </span>
                </li>
                <li className="flex items-start gap-md">
                  <span className="text-secondary-500 font-bold text-lg">•</span>
                  <span className="text-gray-700">
                    <strong>Справедливость:</strong> Честные соревнования по FINA стандартам
                  </span>
                </li>
                <li className="flex items-start gap-md">
                  <span className="text-secondary-500 font-bold text-lg">•</span>
                  <span className="text-gray-700">
                    <strong>Развитие:</strong> Помощь в достижении личных целей
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section className="py-2xl bg-white">
        <div className="max-w-7xl mx-auto px-sm">
          <h2 className="text-3xl font-bold text-primary-900 mb-lg">Наши ценности</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-md">
            {values.map((value, idx) => {
              const Icon = value.icon;
              return (
                <div
                  key={idx}
                  className="p-lg bg-gradient-to-br from-secondary-50 to-primary-50 rounded-xl border border-secondary-100 hover:border-secondary-300 transition"
                >
                  <Icon className="w-10 h-10 text-secondary-500 mb-md" />
                  <h3 className="font-bold text-primary-900 mb-sm text-lg">{value.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{value.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-2xl bg-gray-50">
        <div className="max-w-7xl mx-auto px-sm">
          <h2 className="text-3xl font-bold text-primary-900 mb-lg">Наша команда</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-lg">
            {team.map((member, idx) => (
              <div
                key={idx}
                className="bg-white rounded-xl border border-gray-200 hover:shadow-md transition overflow-hidden"
              >
                <div className="h-32 bg-gradient-to-br from-secondary-400 to-secondary-600"></div>

                <div className="p-lg">
                  <h3 className="font-bold text-primary-900 text-lg mb-xs">{member.name}</h3>
                  <p className="text-sm font-semibold text-secondary-600 mb-md">{member.role}</p>
                  <p className="text-sm text-gray-600">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-2xl bg-gradient-to-r from-primary-50 to-secondary-50">
        <div className="max-w-7xl mx-auto px-sm">
          <h2 className="text-3xl font-bold text-primary-900 mb-lg">Статистика клуба</h2>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-md">
            <div className="p-lg bg-white rounded-xl border border-primary-100">
              <div className="text-3xl font-bold text-primary-700 mb-sm">690+</div>
              <p className="text-sm text-gray-600">Активных участников</p>
            </div>

            <div className="p-lg bg-white rounded-xl border border-secondary-100">
              <div className="text-3xl font-bold text-secondary-600 mb-sm">24</div>
              <p className="text-sm text-gray-600">Соревнований в год</p>
            </div>

            <div className="p-lg bg-white rounded-xl border border-accent-100">
              <div className="text-3xl font-bold text-accent-600 mb-sm">1,200+</div>
              <p className="text-sm text-gray-600">Личных рекордов</p>
            </div>

            <div className="p-lg bg-white rounded-xl border border-primary-100">
              <div className="text-3xl font-bold text-primary-700 mb-sm">7 лет</div>
              <p className="text-sm text-gray-600">Истории клуба</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-2xl bg-white">
        <div className="max-w-7xl mx-auto px-sm">
          <h2 className="text-3xl font-bold text-primary-900 mb-lg">Партнеры и организации</h2>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-lg">
            {[
              'Федерация плавания Казахстана',
              'FINA (Международная федерация плавания)',
              'Комитет физкультуры и спорта РК',
              'Алматинский бассейн "Дельфин"',
              'Бассейн "Олимпийский"',
              'Спортивный центр "Балкоуч"',
            ].map((partner, idx) => (
              <div
                key={idx}
                className="p-lg bg-gray-50 rounded-lg border border-gray-200 text-center"
              >
                <p className="text-gray-700 font-medium">{partner}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-2xl bg-gradient-to-r from-primary-900 to-secondary-700 text-white">
        <div className="max-w-7xl mx-auto px-sm text-center">
          <h2 className="text-3xl font-bold mb-md">Присоединитесь к NAMYS-SWIM</h2>
          <p className="text-xl text-gray-100 mb-lg max-w-2xl mx-auto">
            Начните свой путь в Masters Swimming сегодня. Неважно, новичок ли вы или опытный
            пловец — в нашем клубе найдется место для каждого.
          </p>

          <button className="px-lg py-sm md:py-md bg-accent-500 text-white font-bold rounded-lg hover:bg-accent-600 transition-colors text-lg">
            Зарегистрироваться сейчас
          </button>
        </div>
      </section>
    </main>
  );
}
