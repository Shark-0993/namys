import React, { useState } from 'react';
import { Search, Filter, Trophy, Zap } from 'lucide-react';

export default function Results() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterYear, setFilterYear] = useState('all');
  const [filterType, setFilterType] = useState('all');

  const results = [
    {
      id: 1,
      place: 1,
      name: 'Алмас Сахов',
      category: 'М 45-49',
      distance: '100m Freestyle',
      time: '1:03.45',
      fina: 782,
      competition: 'Чемпионат Masters 2025',
      date: '2025-03-15',
      type: 'pool',
    },
    {
      id: 2,
      place: 2,
      name: 'Динара Утепова',
      category: 'Ж 50-54',
      distance: '200m Freestyle',
      time: '2:45.12',
      fina: 698,
      competition: 'Чемпионат Masters 2025',
      date: '2025-03-15',
      type: 'pool',
    },
    {
      id: 3,
      place: 3,
      name: 'Сергей Иванов',
      category: 'М 60-64',
      distance: '50m Freestyle',
      time: '32.18',
      fina: 615,
      competition: 'Чемпионат Masters 2025',
      date: '2025-03-15',
      type: 'pool',
    },
    {
      id: 4,
      place: 1,
      name: 'Мария Козлова',
      category: 'Ж 35-39',
      distance: '5km Открытая вода',
      time: '1:02:30',
      fina: 825,
      competition: 'Открытая вода Masters 2025',
      date: '2025-03-22',
      type: 'openwater',
    },
    {
      id: 5,
      place: 1,
      name: 'Руслан Бердибаев',
      category: 'М 40-44',
      distance: '100m Butterfly',
      time: '1:15.67',
      fina: 654,
      competition: 'Чемпионат Masters 2025',
      date: '2025-03-15',
      type: 'pool',
    },
  ];

  const clubRecords = [
    {
      category: 'М 45-49',
      distance: '100m Freestyle',
      time: '1:03.45',
      holder: 'Алмас Сахов',
      date: '2025-03-15',
      fina: 782,
    },
    {
      category: 'Ж 50-54',
      distance: '200m Freestyle',
      time: '2:45.12',
      holder: 'Динара Утепова',
      date: '2025-03-15',
      fina: 698,
    },
    {
      category: 'М 40-44',
      distance: '100m Butterfly',
      time: '1:15.67',
      holder: 'Руслан Бердибаев',
      date: '2025-03-15',
      fina: 654,
    },
  ];

  const filteredResults = results.filter((result) => {
    const matchSearch =
      result.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      result.competition.toLowerCase().includes(searchTerm.toLowerCase()) ||
      result.distance.toLowerCase().includes(searchTerm.toLowerCase());

    const matchYear = filterYear === 'all' || new Date(result.date).getFullYear().toString() === filterYear;
    const matchType = filterType === 'all' || result.type === filterType;

    return matchSearch && matchYear && matchType;
  });

  return (
    <main className="flex-1 bg-gray-50 py-xl">
      <div className="max-w-7xl mx-auto px-sm">
        <div className="mb-xl">
          <h1 className="text-4xl font-bold text-primary-900 mb-md">Результаты соревнований</h1>
          <p className="text-gray-600 text-lg">
            Результаты Masters соревнований с оценкой по стандартам FINA
          </p>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-lg mb-lg">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-lg">
            <div className="md:col-span-1">
              <label className="block text-sm font-semibold text-gray-700 mb-sm">
                <Search size={16} className="inline mr-xs" />
                Поиск
              </label>
              <input
                type="text"
                placeholder="ФИО, соревнование, дистанция..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-md py-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-sm">
                <Filter size={16} className="inline mr-xs" />
                Год
              </label>
              <select
                value={filterYear}
                onChange={(e) => setFilterYear(e.target.value)}
                className="w-full px-md py-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary-500 focus:border-transparent"
              >
                <option value="all">Все годы</option>
                <option value="2025">2025</option>
                <option value="2024">2024</option>
                <option value="2023">2023</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-sm">Тип</label>
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="w-full px-md py-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary-500 focus:border-transparent"
              >
                <option value="all">Все типы</option>
                <option value="pool">Бассейн</option>
                <option value="openwater">Открытая вода</option>
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-lg mb-2xl">
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold text-primary-900 mb-lg">Последние результаты</h2>

            <div className="space-y-md">
              {filteredResults.length === 0 ? (
                <div className="text-center py-2xl bg-white rounded-xl border border-gray-200">
                  <Search size={48} className="mx-auto text-gray-300 mb-md" />
                  <p className="text-gray-600 text-lg">Результаты не найдены</p>
                </div>
              ) : (
                filteredResults.map((result) => (
                  <div
                    key={result.id}
                    className="bg-white rounded-xl border border-gray-200 hover:border-secondary-300 transition p-lg"
                  >
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-md items-center">
                      <div className="flex items-center gap-md">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-accent-400 to-accent-600 flex items-center justify-center">
                          <Trophy size={24} className="text-white" />
                        </div>
                        <div>
                          <div className="text-2xl font-bold text-primary-900">#{result.place}</div>
                          <div className="text-xs text-gray-500">место</div>
                        </div>
                      </div>

                      <div>
                        <div className="font-bold text-primary-900">{result.name}</div>
                        <div className="text-sm text-gray-600">{result.category}</div>
                      </div>

                      <div>
                        <div className="text-sm text-gray-500 mb-xs">Дистанция</div>
                        <div className="font-semibold text-primary-900">{result.distance}</div>
                      </div>

                      <div>
                        <div className="text-lg font-bold text-primary-700 mb-xs">{result.time}</div>
                        <div className="flex items-center gap-xs text-accent-600">
                          <Zap size={14} />
                          <span className="text-sm font-semibold">FINA: {result.fina}</span>
                        </div>
                      </div>

                      <div className="text-sm text-gray-600 text-center md:text-right">
                        <div className="font-medium">{result.competition}</div>
                        <div className="text-xs">
                          {new Date(result.date).toLocaleDateString('ru-RU', {
                            day: 'numeric',
                            month: 'short',
                          })}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-primary-900 mb-lg">Рекорды клуба</h2>

            <div className="space-y-md">
              {clubRecords.map((record, idx) => (
                <div
                  key={idx}
                  className="bg-white rounded-xl border border-accent-200 hover:shadow-md transition p-lg bg-gradient-to-br from-accent-50 to-white"
                >
                  <div className="flex items-start justify-between mb-sm">
                    <div>
                      <div className="text-xs font-semibold text-accent-700 uppercase tracking-wide mb-xs">
                        {record.category}
                      </div>
                      <div className="font-bold text-primary-900 text-sm">{record.distance}</div>
                    </div>
                    <Trophy size={20} className="text-accent-600" />
                  </div>

                  <div className="border-t border-accent-100 pt-sm mt-sm">
                    <div className="text-2xl font-bold text-primary-700 mb-xs">{record.time}</div>
                    <div className="text-xs text-gray-600 mb-xs">
                      <span className="font-semibold">Рекордсмен:</span> {record.holder}
                    </div>
                    <div className="text-xs text-accent-600 font-semibold flex items-center gap-xs">
                      <Zap size={12} />
                      FINA: {record.fina}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
