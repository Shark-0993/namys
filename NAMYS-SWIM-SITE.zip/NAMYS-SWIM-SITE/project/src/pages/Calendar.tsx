import React, { useState } from 'react';
import { Calendar, Filter, MapPin, Users } from 'lucide-react';

export default function CalendarPage() {
  const [filterType, setFilterType] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');

  const events = [
    {
      id: 1,
      title: 'Чемпионат Masters 25м',
      date: '2025-03-15',
      time: '09:00',
      location: 'Бассейн "Дельфин", Алматы',
      type: 'pool',
      category: 'championship',
      poolSize: '25m',
      distances: '50m, 100m, 200m, 400m, 1500m',
      deadline: '2025-03-10',
      participants: 145,
      status: 'open',
    },
    {
      id: 2,
      title: 'Открытая вода Masters 5km',
      date: '2025-03-22',
      time: '08:00',
      location: 'Озеро Балхаш',
      type: 'openwater',
      category: 'open',
      distances: '1km, 2km, 5km',
      deadline: '2025-03-17',
      participants: 62,
      status: 'open',
    },
    {
      id: 3,
      title: 'Turbo Masters Sprint 50m',
      date: '2025-04-05',
      time: '14:00',
      location: 'Бассейн "Олимпийский", Алматы',
      type: 'pool',
      category: 'sprint',
      poolSize: '50m',
      distances: '50m, 100m',
      deadline: '2025-04-02',
      participants: 98,
      status: 'open',
    },
    {
      id: 4,
      title: 'Кубок Masters Distance',
      date: '2025-04-20',
      time: '10:00',
      location: 'Бассейн "Дельфин", Алматы',
      type: 'pool',
      category: 'distance',
      poolSize: '25m',
      distances: '400m, 800m, 1500m',
      deadline: '2025-04-15',
      participants: 78,
      status: 'open',
    },
  ];

  const filteredEvents = events.filter((event) => {
    const matchType = filterType === 'all' || event.type === filterType;
    const matchCategory = filterCategory === 'all' || event.category === filterCategory;
    return matchType && matchCategory;
  });

  return (
    <main className="flex-1 bg-gray-50 py-xl">
      <div className="max-w-7xl mx-auto px-sm">
        <div className="mb-xl">
          <h1 className="text-4xl font-bold text-primary-900 mb-md">Календарь соревнований</h1>
          <p className="text-gray-600 text-lg">
            Выберите соревнование и зарегистрируйтесь на участие
          </p>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 p-lg mb-lg">
          <div className="flex flex-col md:flex-row gap-lg">
            <div className="flex-1">
              <label className="block text-sm font-semibold text-gray-700 mb-sm">
                <Filter size={16} className="inline mr-xs" />
                Тип
              </label>
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="w-full px-md py-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary-500 focus:border-transparent"
              >
                <option value="all">Все события</option>
                <option value="pool">Бассейн</option>
                <option value="openwater">Открытая вода</option>
              </select>
            </div>

            <div className="flex-1">
              <label className="block text-sm font-semibold text-gray-700 mb-sm">
                Категория
              </label>
              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="w-full px-md py-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-secondary-500 focus:border-transparent"
              >
                <option value="all">Все категории</option>
                <option value="championship">Чемпионат</option>
                <option value="sprint">Спринт</option>
                <option value="distance">Дистанция</option>
                <option value="open">Открытая вода</option>
              </select>
            </div>
          </div>
        </div>

        {filteredEvents.length === 0 ? (
          <div className="text-center py-2xl bg-white rounded-xl border border-gray-200">
            <Calendar size={48} className="mx-auto text-gray-300 mb-md" />
            <p className="text-gray-600 text-lg">По вашим критериям событий не найдено</p>
          </div>
        ) : (
          <div className="space-y-md">
            {filteredEvents.map((event) => (
              <div
                key={event.id}
                className="bg-white rounded-xl border border-gray-200 hover:border-secondary-300 hover:shadow-md transition-all p-lg"
              >
                <div className="grid grid-cols-1 md:grid-cols-4 gap-lg items-start">
                  <div>
                    <div className="text-sm text-gray-500 uppercase tracking-wide mb-xs">
                      {event.type === 'pool' ? 'Бассейн' : 'Открытая вода'}
                    </div>
                    <h3 className="text-xl font-bold text-primary-900 mb-md">{event.title}</h3>

                    <div className="space-y-sm text-gray-600">
                      <div className="flex items-center gap-sm">
                        <Calendar size={16} className="text-secondary-500" />
                        <span>
                          {new Date(event.date).toLocaleDateString('ru-RU', {
                            day: 'numeric',
                            month: 'long',
                            year: 'numeric',
                          })}{' '}
                          в {event.time}
                        </span>
                      </div>

                      <div className="flex items-start gap-sm">
                        <MapPin size={16} className="text-secondary-500 mt-0.5" />
                        <span>{event.location}</span>
                      </div>

                      <div className="flex items-center gap-sm">
                        <Users size={16} className="text-secondary-500" />
                        <span>{event.participants} участников зарегистрировано</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <div className="text-sm font-semibold text-gray-700 mb-sm">Дистанции</div>
                    <div className="text-sm text-gray-600">{event.distances}</div>

                    {event.type === 'pool' && (
                      <>
                        <div className="text-sm font-semibold text-gray-700 mt-md mb-sm">
                          Размер бассейна
                        </div>
                        <div className="text-sm text-gray-600">{event.poolSize}</div>
                      </>
                    )}
                  </div>

                  <div>
                    <div className="text-sm font-semibold text-gray-700 mb-sm">Дедлайн</div>
                    <div className="text-sm text-gray-600 mb-md">
                      {new Date(event.deadline).toLocaleDateString('ru-RU', {
                        day: 'numeric',
                        month: 'long',
                      })}
                    </div>

                    <div className="inline-block px-md py-xs bg-green-100 text-green-800 text-xs font-semibold rounded">
                      {event.status === 'open' ? 'Регистрация открыта' : 'Закрыто'}
                    </div>
                  </div>

                  <div className="flex flex-col gap-sm">
                    <button className="w-full px-lg py-sm bg-primary-700 text-white font-semibold rounded-lg hover:bg-primary-800 transition-colors">
                      Зарегистрироваться
                    </button>
                    <button className="w-full px-lg py-sm border border-primary-700 text-primary-700 font-semibold rounded-lg hover:bg-primary-50 transition-colors">
                      Подробнее
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </main>
  );
}
