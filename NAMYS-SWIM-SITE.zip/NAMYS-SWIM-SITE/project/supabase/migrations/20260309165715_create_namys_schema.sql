/*
  # Create NAMYS-SWIM database schema

  1. New Tables
    - `users` (extends auth.users)
      - `id` (uuid, primary key, references auth.users)
      - `full_name` (text)
      - `date_of_birth` (date)
      - `category` (text: Masters age group)
      - `gender` (text: Male/Female)
      - `club_id` (uuid, references clubs)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `competitions`
      - `id` (uuid, primary key)
      - `title` (text)
      - `description` (text)
      - `date` (timestamptz)
      - `location` (text)
      - `type` (text: pool/openwater)
      - `pool_size` (text: 25m/50m)
      - `status` (text: draft/published/closed)
      - `registration_deadline` (timestamptz)
      - `max_participants` (integer)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `competition_distances`
      - `id` (uuid, primary key)
      - `competition_id` (uuid, references competitions)
      - `distance_name` (text: 50m, 100m, etc)
      - `stroke` (text: Freestyle, Backstroke, Breaststroke, Butterfly, IM)
      - `pool_length` (integer)
      - `created_at` (timestamp)
    
    - `registrations`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references users)
      - `competition_id` (uuid, references competitions)
      - `status` (text: registered/confirmed/withdrawn)
      - `distances` (text[])
      - `registered_at` (timestamp)
    
    - `results`
      - `id` (uuid, primary key)
      - `registration_id` (uuid, references registrations)
      - `distance_id` (uuid, references competition_distances)
      - `time` (text: HH:MM:SS.MS format)
      - `place` (integer)
      - `fina_score` (integer)
      - `record_type` (text: null/club_record/national_record)
      - `completed_at` (timestamp)
    
    - `clubs`
      - `id` (uuid, primary key)
      - `name` (text)
      - `founded_year` (integer)
      - `location` (text)
      - `description` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Users can view own data and all public competition/results data
    - Only authenticated users can register for competitions
    - Only admins can create/edit competitions
*/

CREATE TABLE IF NOT EXISTS clubs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  founded_year integer,
  location text,
  description text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  full_name text,
  date_of_birth date,
  category text,
  gender text,
  club_id uuid REFERENCES clubs(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS competitions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  date timestamptz NOT NULL,
  location text NOT NULL,
  type text NOT NULL CHECK (type IN ('pool', 'openwater')),
  pool_size text CHECK (pool_size IN ('25m', '50m') OR pool_size IS NULL),
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'closed')),
  registration_deadline timestamptz NOT NULL,
  max_participants integer,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS competition_distances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  competition_id uuid NOT NULL REFERENCES competitions(id) ON DELETE CASCADE,
  distance_name text NOT NULL,
  stroke text NOT NULL CHECK (stroke IN ('Freestyle', 'Backstroke', 'Breaststroke', 'Butterfly', 'IM')),
  pool_length integer NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS registrations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  competition_id uuid NOT NULL REFERENCES competitions(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'registered' CHECK (status IN ('registered', 'confirmed', 'withdrawn')),
  distances text[],
  registered_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  registration_id uuid NOT NULL REFERENCES registrations(id) ON DELETE CASCADE,
  distance_id uuid NOT NULL REFERENCES competition_distances(id) ON DELETE CASCADE,
  time text NOT NULL,
  place integer,
  fina_score integer,
  record_type text CHECK (record_type IN (NULL, 'club_record', 'national_record')),
  completed_at timestamptz DEFAULT now()
);

ALTER TABLE clubs ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE competitions ENABLE ROW LEVEL SECURITY;
ALTER TABLE competition_distances ENABLE ROW LEVEL SECURITY;
ALTER TABLE registrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE results ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Clubs are viewable by everyone"
  ON clubs FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Users can view own profile"
  ON users FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON users FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Authenticated users can insert own profile"
  ON users FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Competitions are viewable by everyone"
  ON competitions FOR SELECT
  TO public
  USING (status = 'published');

CREATE POLICY "Authenticated users can view all competition details"
  ON competitions FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Competition distances are viewable with competition"
  ON competition_distances FOR SELECT
  TO public
  USING (
    EXISTS (
      SELECT 1 FROM competitions
      WHERE competitions.id = competition_distances.competition_id
      AND competitions.status = 'published'
    )
  );

CREATE POLICY "Authenticated users can view all competition distances"
  ON competition_distances FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can view own registrations"
  ON registrations FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can register for competitions"
  ON registrations FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own registrations"
  ON registrations FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Results are viewable by everyone"
  ON results FOR SELECT
  TO public
  USING (
    EXISTS (
      SELECT 1 FROM registrations
      WHERE registrations.id = results.registration_id
      AND EXISTS (
        SELECT 1 FROM competitions
        WHERE competitions.id = registrations.competition_id
        AND competitions.status = 'published'
      )
    )
  );

CREATE INDEX idx_users_club_id ON users(club_id);
CREATE INDEX idx_competitions_status ON competitions(status);
CREATE INDEX idx_competitions_date ON competitions(date);
CREATE INDEX idx_competition_distances_competition_id ON competition_distances(competition_id);
CREATE INDEX idx_registrations_user_id ON registrations(user_id);
CREATE INDEX idx_registrations_competition_id ON registrations(competition_id);
CREATE INDEX idx_results_registration_id ON results(registration_id);
CREATE INDEX idx_results_distance_id ON results(distance_id);
